function [theta, b] = TDL_Demo(Y, A, lambda, beta, Maxiter)
%%% Demo code for TDL method. Details please refer to our paper.

tol = 1e-3;
tol_inter = 1e-3;
maxiter = Maxiter;
iter = 0;
maxiter_inter = Maxiter;
T = length(A);
N = size(Y,1);
p = size(A{1,1}(:,:,1),1);

theta = cell(T,1);
Orig_theta = cell(T,1);
b=zeros(T,1);
Z0 = cell(T,1);
Z1 = cell(T,1);
Z2 = cell(T,1);
Z3 = cell(T,1);
Z4 = cell(T,1);

U0 = cell(T,1);
U1 = cell(T,1);
U2 = cell(T,1);
U3 = cell(T,1);
U4 = cell(T,1);
U5 = cell(T,1);
U0_Check = cell(T,1);
U1_Check = cell(T,1);
U2_Check = cell(T,1);
U3_Check = cell(T,1);
U4_Check = cell(T,1);
U5_Check = cell(T,1);

%%%%%%%%%  You need to initialize parameters %%%%%%%%%

while iter<maxiter
    iter = iter +1;
    for i=1:T
        Orig_theta{i,1} = theta{i,1};
    end

    for i=1:T
        iter_inter = 0;
        while iter_inter<maxiter_inter
            iter_inter = iter_inter+1;
            Z0_Pre = Z0{i,1};
            
            Obj_Pre = Compute_Logistic_Obj(Z0_Pre,A{i,1},Y,b(i,1));
            Obj_Pre = Obj_Pre + mu*(norm(theta{i,1}-Z0_Pre+U0{i,1},'fro')^2 - norm(U0{i,1},'fro')^2)/2;
            
            grad_theta = logistic_grad_W(Z0{i,1},A{i,1},Y,b(i,1));
            grad_theta = grad_theta + mu*(Z0{i,1}-theta{i,1}-U0{i,1});
            Z0{i,1} = Z0{i,1} - rate_theta*grad_theta;
            Z0{i,1} = Z0{i,1}-diag(diag(Z0{i,1}));
            Obj =  Compute_Logistic_Obj(Z0{i,1},A{i,1},Y,b(i,1))+ mu*(norm(theta{i,1}-Z0{i,1}+U0{i,1},'fro')^2-norm(U0{i,1},'fro')^2)/2;
            if sum(sum(abs(Z0_Pre-Z0{i,1})))<=tol_inter
                break;
            end
            
        end
    end


    for i=1:T
        Z1{i,1} = solve_l1(theta{i,1}+U1{i,1},lambda/mu);
    end

    for i=2:T
        AA = theta{i-1,1}-theta{i,1}+U2{i-1,1}-U3{i,1};
        eta = 2*beta/mu;
        E = solve_l1l2(AA,eta);
        Z2{i-1,1} = (theta{i-1,1}+theta{i,1}+U2{i-1,1}+U3{i,1})/2-E/2;
        Z3{i,1} = (theta{i-1,1}+theta{i,1}+U2{i-1,1}+U3{i,1})/2+E/2;
    end

   for i=1:T
        Z4{i,1} = (theta{i,1}'+U4{i,1}+theta{i,1}+U5{i,1})/2;
    end
    

    for i=1:T
        theta{i,1} = -(U0{i,1}-Z0{i,1}+U1{i,1}-Z1{i,1}+U3{i,1}-Z3{i,1}+...
            U2{i,1}-Z2{i,1}+(U4{i,1}-Z4{i,1})'+U5{i,1}-Z4{i,1})/6;
    end
    
       
    for i=1:T
        
        iter_inter = 0;
        while iter_inter<maxiter_inter
            iter_inter = iter_inter+1;
            BPre   = b(i,1);
            Obj_Preb = Compute_Logistic_Obj(Z0{i,1},A{i,1},Y,BPre);
            grad_b = logistic_grad_b(Z0{i,1},A{i,1},Y,b(i,1));
            b(i,1) = b(i,1) - rate_b*grad_b;
            Obj_b = Compute_Logistic_Obj(Z0{i,1},A{i,1},Y,b(i,1));
            if sum(abs(Obj_Preb-Obj_b))<=tol_inter
                break;
            end
        end
        
    end
    %%% you need to updata auxillary variable and check Convergence

end





%%%additional functions

function grad = logistic_grad_W(W,X,Y,delta)
Num = size(Y,1);
grad = zeros(size(X(:,:,1)));
for i=1:Num
    grad = grad + exp(-Y(i,1)*(trace(W'*X(:,:,i))+delta))*(-Y(i,1)*X(:,:,i))/...
        (1+exp(-Y(i,1)*(trace(W'*X(:,:,i))+delta)));
end
grad = grad/Num;
function b = logistic_grad_b(W,X,Y,delta)
Num = size(Y,1);
b = 0;
for i=1:Num
    b = b + exp(-Y(i,1)*(trace(W'*X(:,:,i))+delta))*(-Y(i,1))/...
        (1+exp(-Y(i,1)*(trace(W'*X(:,:,i))+delta)));
end
b = b/Num;



function objective_value = Compute_Logistic_Obj(W,X,Y,b)
objective_value = 0;
Num = size(Y,1);
for i=1:Num
    objective_value = objective_value + log( 1+exp(-Y(i,1)*(trace(W'*X(:,:,i))+b)) );
end
objective_value = objective_value/Num;

function [E] = solve_l1(W,lambda)
if(lambda<0)
    disp('There input are error')
end
E=zeros(size(W));
temp=abs(W)-lambda;
temp(temp<=0)=0;
E=sign(W).*temp;


function [E] = solve_l1l2(W,lambda)
n = size(W,2);
E = W;
for i=1:n
    E(:,i) = solve_l2(W(:,i),lambda);
end


function [x] = solve_l2(w,lambda)
nw = norm(w,2);
if nw>lambda
    x = (1-lambda/nw)*w;
else
    x = zeros(length(w),1);
end
